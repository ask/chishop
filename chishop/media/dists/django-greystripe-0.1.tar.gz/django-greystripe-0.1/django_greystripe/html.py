from BeautifulSoup import BeautifulSoup
from django.conf import settings
from django_greystripe.models import FeaturedGame
from django_greystripe.utils import fetch_url_if_changed

GAMEJUMP_URL_PREFIX = "http://opera.gamejump.com/WhiteLabelWap/"
GAMEJUMP_FEATURED_PAGE = "http://opera.gamejump.com/WhiteLabelWap/index.htm"
DEFAULT_GAME_LIMIT = 10

class FeaturedGamesScraper(object):
    parser = BeautifulSoup

    def __init__(self, url=GAMEJUMP_FEATURED_PAGE, limit=DEFAULT_GAME_LIMIT):
        """ Construct a FeaturedGamesScraper object instance """
        page = fetch_url_if_changed(url, url).read()
        self.soup = self.parser(page)
        self.limit = limit

    def get_featured_games(self):
        """ Get featured games from the GameJump home page """
        soup = self.soup
        limit = self.limit

        feat_table = soup.find("table")
        feat_tds = feat_table.findAll("td", "col2", limit=limit)
        links = [td.find("a") for td in feat_tds]
        games = [(link.string, GAMEJUMP_URL_PREFIX + link.get("href"))
                        for link in links]

        return games

    def refresh_featured_games(self):
        FeaturedGame.objects.all().delete()
        for sort, game in enumerate(self.get_featured_games()):
            game_name, game_url = game
            game_obj, created = FeaturedGame.objects.get_or_create(
                                                        name=game_name,
                                                        url=game_url,
                                                        sort=sort)
            if not created:
                game_obj.save()



def main():
    print FeaturedGamesScraper().get_featured_games()
