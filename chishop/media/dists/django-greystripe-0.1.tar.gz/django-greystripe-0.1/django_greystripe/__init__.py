URL_FORMAT = "http://%s/partnerDownload.php?partnerid=%d&filename=%s"
SERVER = "www.greystripe.com"


def greystripe_url(filename, partner_id):
    return URL_FORMAT % (SERVER, partner_id, filename)
