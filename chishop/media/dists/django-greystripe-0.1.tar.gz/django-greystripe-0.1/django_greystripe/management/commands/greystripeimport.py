from django.core.management.base import CommandError, NoArgsCommand

class Command(NoArgsCommand):
    option_list = NoArgsCommand.option_list + (
    )

    help = ("Import Greystripe data")

    requires_model_validation = True
    can_import_settings = True

    def handle_noargs(self, **options):
        from django_greystripe.importers import GreystripeImporter
        importer = GreystripeImporter()
        importer.import_to_django()
