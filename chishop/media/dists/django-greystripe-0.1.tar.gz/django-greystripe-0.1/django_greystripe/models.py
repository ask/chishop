from django.db import models
from django.utils.translation import ugettext_lazy as _


class Category(models.Model):
    """ Defines the categories into which the applications are grouped."""
    name = models.CharField(_(u"name"), max_length=255)
    sortOrder = models.SmallIntegerField(_(u"sort order"))

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = _(u"category")
        verbose_name_plural = _(u"categories")


class Vendor(models.Model):
    """ A class naming device vendors and useful for grouping
        devices according to manfacturers when presenting a list of
        devices to users to assist them in finding the right application
        version. """
    name = models.CharField(_(u"name"), null=True, max_length=255)

    class Meta:
        verbose_name = _(u"vendor")
        verbose_name_plural = _(u"vendors")

    def __unicode__(self):
        if self.name:
            return self.name
        # May be NULL, so return empty string.
        return u""


class Device(models.Model):
    """ Represents a single mobile device. """
    name = models.CharField(_(u"name"), max_length=255)
    wurflId = models.CharField(_(u"WURFL Id"), max_length=64)
    wurflImageAvailable = models.BooleanField(_(u"WURLF image available"))
    vendor = models.ForeignKey(Vendor)

    class Meta:
        verbose_name = _(u"device")
        verbose_name_plural = _(u"devices")

    def __unicode__(self):
        return self.name


class Application(models.Model):
    """ Information about an application """
    name = models.CharField(_(u"name"), max_length=255)
    publisher = models.CharField(_(u"publisher"), max_length=255)
    summary = models.CharField(_(u"summary"), max_length=255)
    description = models.TextField(_(u"description"), blank=True)
    rating = models.FloatField(_(u"rating"), default=1.0)
    sortOrder = models.SmallIntegerField(_(u"sort order"))
    reviews = models.TextField(_(u"reviews"), blank=True, null=True)
    awards = models.TextField(_(u"awards"), blank=True, null=True)
    webThumb = models.CharField(_(u"image thumbnail (Web)"), max_length=255,
            null=True)
    wapThumb = models.CharField(_(u"image thumbnail (WAP)"), max_length=255,
            null=True)
    categories = models.ManyToManyField(Category)

    class Meta:
        verbose_name = _(u"application")
        verbose_name_plural = _(u"applications")

    def __unicode__(self):
        return self.name


class ApplicationDeviceMap(models.Model):
    application = models.ForeignKey(Application)
    device = models.ForeignKey(Device)
    versionId = models.IntegerField(_(u"version ID"))

    class Meta:
        verbose_name = _(u"application device map")
        verbose_name_plural = _(u"application device maps")

    def __unicode__(self):
        return u"%d -> %s" % (self.versionId, self.device.name)


class Screenshot(models.Model):
    """ information about the screen shots available. """
    filename = models.CharField(_(u"filename"), max_length=255)
    caption = models.CharField(_(u"caption"), max_length=255, null=True)
    width = models.IntegerField(_(u"width"))
    height = models.IntegerField(_(u"height"))
    sortOrder = models.SmallIntegerField(_(u"sort order"))
    application = models.ForeignKey(Application)

    class Meta:
        verbose_name = _(u"screenshot")
        verbose_name_plural = _(u"screenshots")

    def __unicode__(self):
        return self.filename

class FileMetadata(models.Model):
    """ Metadata about the source files used for getting
    information. This model is only used internally to see
    what files has changed on the provider site. """
    filename = models.CharField(_(u"filename"), max_length=255)
    url = models.URLField(_(u"URL"))
    last_modified = models.CharField(_(u"last modified"),
                                    max_length=255, null=True)

    class Meta:
        verbose_name = _(u"file metadata")
        verbose_name_plural = _(u"file metadata")

    def __unicode__(self):
        return u"%s -> %s (%s)" % (self.filename, self.url,
                self.last_modified)

class FeaturedGame(models.Model):
    name = models.CharField(_(u"name"), max_length=255)
    url = models.URLField(_(u"URL"))
    sort = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = _(u"featured game")
        verbose_name = _(u"featured games")

    def __unicode__(self):
        return u"%s (%s)" % (self.name, self.url)
