import os
import sys
import zipfile
import urllib2
from cStringIO import StringIO
from yadayada.importers.xml import XPathImporter
from yadayada.importers.xml import ElementHandler, RelationElementHandler
from django_greystripe.models import Category, Screenshot, Device
from django_greystripe.models import Vendor, Application, ApplicationDeviceMap
from django_greystripe import greystripe_url
from django.conf import settings
from yadayada.importers.image import ImageImporter
from django_greystripe.models import FileMetadata
from django_greystripe.utils import fetch_url_if_changed

DATA_FILENAME = "adwrap_data_en_US.zip"
IMAGE_FILENAME = "adwrap_images.zip"


class Logger(object):

    def __init__(self, on=True):
        self.on = on

    def __call__(self, msg):
        self.log(msg)

    def log(self, msg):
        if self.on:
            sys.stderr.write(msg + "\n")

class GreystripeImageImporter(object):
    image_prefix = settings.GREYSTRIPE_MEDIA_PREFIX
    importer_cls = ImageImporter
    verbose = False

    def __init__(self, **kwargs):
        self.verbose = kwargs.get("verbose", self.verbose)
        self.importer = self.importer_cls(upload_to=self.image_prefix)
        self.log = Logger(on=self.verbose)

    def import_images(self):
        self.log("Importing images...")
        for dirpath, dirnames, filenames in os.walk("adwrap_images/"):
            for filename in filenames:
                self.importer.import_image_by_filename(
                        os.path.join(dirpath, filename))


class GreystripeImporter(XPathImporter):
    partner_id = settings.GREYSTRIPE_PARTNER_ID
    data_filename = DATA_FILENAME
    xpath_prefix = "/AdWrapApplications"

    handlers = (
        ("Category",
            ElementHandler(model=Category, pk="categoryId")),
        ("DeviceVendor",
            ElementHandler(model=Vendor, pk="vendorId")),
        ("Device",
            ElementHandler(model=Device, pk="deviceId",
                        fkey=[("vendorId", Vendor, "vendor")])),
        ("Application",
            ElementHandler(model=Application, pk="applicationId")),
        ("ApplicationScreenshot",
            ElementHandler(model=Screenshot, pk=None,
                        fkey=[("applicationId", Application, "application")])),
        ("CategoryToApplication",
            RelationElementHandler(
                        obj_model=Application, obj_pk="applicationId",
                        rel_model=Category, rel_pk="categoryId",
                        rel_manager="categories")),
        ("ApplicationDeviceMapping",
            ElementHandler(model=ApplicationDeviceMap, pk=None,
                ignore_fields=["sortOrder"], fkey=[
                ("applicationId", Application, "application"),
                ("deviceId", Device, "device"),
        ])),
    )

    def __init__(self, *args, **kwargs):
        verbose = kwargs.get("verbose", False)
        self.log = Logger(on=verbose)
        super(GreystripeImporter, self).__init__(*args, **kwargs)

    def import_to_django(self, *args, **kwargs):
        self.log("Importing objects...")
        return super(GreystripeImporter, self).import_to_django(
                *args, **kwargs)

    def open_document(self):
        data_fh = self.download_data_fh()
        xml_fh = self.get_xml_in_zip(data_fh)
        return super(GreystripeImporter, self).open_document(xml_fh)

    def download_data_fh(self):
        url = greystripe_url(self.data_filename, self.partner_id)
        self.log("Downloading %s..." % (url, ))
        return StringIO(fetch_url_if_changed(url, self.data_filename))

    def get_xml_in_zip(self, zip_fh):
        zip = zipfile.ZipFile(zip_fh)
        xml_filename = [name for name in zip.namelist()
                             if name.endswith(".xml")][0]
        self.log("Reading file %s from zip file..." % (xml_filename, ))
        return StringIO(zip.read(xml_filename))
