import urllib2
from django_greystripe.models import FileMetadata


def fetch_url_if_changed(url, filename):
    request = urllib2.Request(url)
    opener = urllib2.build_opener()
    filemeta, created = FileMetadata.objects.get_or_create(url=url,
                                                           filename=filename)
    if filemeta.last_modified:
        request.add_header("If-Modified-Since",
                           filemeta.last_modified)

    data_stream = opener.open(request)
    filemeta.last_modified = data_stream.headers.get("Last-Modified")
    filemeta.save()

    return data_stream
